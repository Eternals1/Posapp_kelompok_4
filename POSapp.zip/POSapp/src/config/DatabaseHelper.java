package config;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;

public class DatabaseHelper {
    private static final String URL = "jdbc:postgresql://localhost:5432/db_kasir";
    private static final String USER = "postgres"; // Ganti kalau username berbeda
    private static final String PASSWORD = "jayakontol22"; // Ganti sesuai password PostgreSQL kamu

    private static Connection connection;

    public static Connection getConnection() throws SQLException {
        if (connection == null || connection.isClosed()) {
            try {
                Class.forName("org.postgresql.Driver");
                connection = DriverManager.getConnection(URL, USER, PASSWORD);
                System.out.println("🔌 Database terkoneksi!");
            } catch (ClassNotFoundException e) {
                System.err.println("❌ PostgreSQL JDBC Driver tidak ditemukan.");
                e.printStackTrace();
            } catch (SQLException e) {
                System.err.println("❌ Gagal koneksi ke database.");
                e.printStackTrace();
                throw e;
            }
        }
        return connection;
    }
}
