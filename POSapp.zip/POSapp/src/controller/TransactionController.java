/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package controller;
import config.DatabaseHelper;
import model.Transaction;
import model.TransactionItem;
import java.sql.*;
import java.util.List;
/**
 *
 * @author LENOVO
 */
public class TransactionController {
   // Simpan transaksi dan item-nya ke DB
public static boolean saveTransaction(Transaction transaksi, List<TransactionItem> items) {
    String insertTrans = "INSERT INTO transactions (user_id, total, payment, change) VALUES (?, ?, ?, ?) RETURNING id";
    String insertItem = "INSERT INTO transaction_items (transaction_id, product_id, quantity, price, subtotal) VALUES (?, ?, ?, ?, ?)";

    try (Connection conn = DatabaseHelper.getConnection()) {
        conn.setAutoCommit(false); // Mulai transaksi

        // 1. Simpan transaksi & ambil ID-nya
        int transaksiId = -1;
        try (PreparedStatement stmt = conn.prepareStatement(insertTrans)) {
            stmt.setInt(1, transaksi.getUserId());
            stmt.setDouble(2, transaksi.getTotal());
            stmt.setDouble(3, transaksi.getPayment());
            stmt.setDouble(4, transaksi.getChange());

            ResultSet rs = stmt.executeQuery();
            if (rs.next()) {
                transaksiId = rs.getInt(1);
            }
        }

        // 2. Simpan semua item
        try (PreparedStatement stmtItem = conn.prepareStatement(insertItem)) {
            for (TransactionItem item : items) {
                stmtItem.setInt(1, transaksiId);
                stmtItem.setInt(2, item.getProductId());
                stmtItem.setInt(3, item.getQuantity());
                stmtItem.setDouble(4, item.getPrice());
                stmtItem.setDouble(5, item.getSubtotal());
                stmtItem.addBatch();
            }
            stmtItem.executeBatch();
        }

        conn.commit();
        return true;

    } catch (SQLException e) {
        e.printStackTrace();
        return false;
    }
}
 
}
