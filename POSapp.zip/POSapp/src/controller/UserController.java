/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package controller;
import config.DatabaseHelper; import model.User;
import java.sql.*; import java.util.ArrayList; import java.util.List;
/**
 *
 * @author LENOVO
 */
public class UserController {
    // Ambil semua user dari database
public static List<User> getAllUsers() {
    List<User> userList = new ArrayList<>();

    String query = "SELECT * FROM users ORDER BY id ASC";
    try (Connection conn = DatabaseHelper.getConnection();
         Statement stmt = conn.createStatement();
         ResultSet rs = stmt.executeQuery(query)) {

        while (rs.next()) {
            User user = new User(
                    rs.getInt("id"),
                    rs.getString("name"),
                    rs.getString("email"),
                    rs.getString("username"),
                    rs.getString("password"),
                    rs.getString("role")
            );
            userList.add(user);
        }

    } catch (SQLException e) {
        e.printStackTrace();
    }

    return userList;
}

// Tambah user
public static boolean addUser(User user) {
    String query = "INSERT INTO users (name, email, username, password, role) VALUES (?, ?, ?, ?, ?)";

    try (Connection conn = DatabaseHelper.getConnection();
         PreparedStatement stmt = conn.prepareStatement(query)) {

        stmt.setString(1, user.getName());
        stmt.setString(2, user.getEmail());
        stmt.setString(3, user.getUsername());
        stmt.setString(4, user.getPassword());
        stmt.setString(5, user.getRole());

        return stmt.executeUpdate() > 0;

    } catch (SQLException e) {
        e.printStackTrace();
        return false;
    }
}

// Edit user
public static boolean updateUser(User user) {
    String query = "UPDATE users SET name=?, email=?, username=?, password=?, role=? WHERE id=?";

    try (Connection conn = DatabaseHelper.getConnection();
         PreparedStatement stmt = conn.prepareStatement(query)) {

        stmt.setString(1, user.getName());
        stmt.setString(2, user.getEmail());
        stmt.setString(3, user.getUsername());
        stmt.setString(4, user.getPassword());
        stmt.setString(5, user.getRole());
        stmt.setInt(6, user.getId());

        return stmt.executeUpdate() > 0;

    } catch (SQLException e) {
        e.printStackTrace();
        return false;
    }
}

// Hapus user
public static boolean deleteUser(int userId) {
    String query = "DELETE FROM users WHERE id=?";

    try (Connection conn = DatabaseHelper.getConnection();
         PreparedStatement stmt = conn.prepareStatement(query)) {

        stmt.setInt(1, userId);
        return stmt.executeUpdate() > 0;

    } catch (SQLException e) {
        e.printStackTrace();
        return false;
    }
}

}
