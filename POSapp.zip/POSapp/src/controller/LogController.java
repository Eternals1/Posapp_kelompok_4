/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package controller;
import config.DatabaseHelper;
import model.Log;

import java.sql.*;
import java.time.LocalDateTime;
import java.util.ArrayList;
import java.util.List;
/**
 *
 * @author LENOVO
 */
public class LogController {
   
    // Tambah log baru
public static void insertLog(Log log) {
    String query = "INSERT INTO logs (user_id, action_type, description) VALUES (?, ?, ?)";

    try (Connection conn = DatabaseHelper.getConnection();
         PreparedStatement stmt = conn.prepareStatement(query)) {

        stmt.setInt(1, log.getUserId());
        stmt.setString(2, log.getActionType());
        stmt.setString(3, log.getDescription());

        stmt.executeUpdate();

    } catch (SQLException e) {
        e.printStackTrace();
    }
}

// Ambil semua log
public static List<Log> getAllLogs() {
    List<Log> logs = new ArrayList<>();
    String query = "SELECT * FROM logs ORDER BY timestamp DESC";

    try (Connection conn = DatabaseHelper.getConnection();
         Statement stmt = conn.createStatement();
         ResultSet rs = stmt.executeQuery(query)) {

        while (rs.next()) {
            Log log = new Log(
                    rs.getInt("id"),
                    rs.getInt("user_id"),
                    rs.getString("action_type"),
                    rs.getString("description"),
                    rs.getTimestamp("timestamp").toLocalDateTime()
            );
            logs.add(log);
        }

    } catch (SQLException e) {
        e.printStackTrace();
    }

    return logs;
}

// Ambil log berdasarkan action_type
public static List<Log> getLogsByAction(String actionType) {
    List<Log> logs = new ArrayList<>();
    String query = "SELECT * FROM logs WHERE action_type = ? ORDER BY timestamp DESC";

    try (Connection conn = DatabaseHelper.getConnection();
         PreparedStatement stmt = conn.prepareStatement(query)) {

        stmt.setString(1, actionType);
        ResultSet rs = stmt.executeQuery();

        while (rs.next()) {
            Log log = new Log(
                    rs.getInt("id"),
                    rs.getInt("user_id"),
                    rs.getString("action_type"),
                    rs.getString("description"),
                    rs.getTimestamp("timestamp").toLocalDateTime()
            );
            logs.add(log);
        }

    } catch (SQLException e) {
        e.printStackTrace();
    }

    return logs;
}
    
    
}
