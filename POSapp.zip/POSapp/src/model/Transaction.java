/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package model;
import java.time.LocalDateTime;
/**
 *
 * @author LENOVO
 */
public class Transaction {
     private int id;
     private int userId;
     private LocalDateTime date;
     private double total;
     private double payment;
     private double change;
     
     public Transaction() {}

public Transaction(int id, int userId, LocalDateTime date, double total, double payment, double change) {
    this.id = id;
    this.userId = userId;
    this.date = date;
    this.total = total;
    this.payment = payment;
    this.change = change;
}

// Getters & Setters
public int getId() { return id; }
public void setId(int id) { this.id = id; }

public int getUserId() { return userId; }
public void setUserId(int userId) { this.userId = userId; }

public LocalDateTime getDate() { return date; }
public void setDate(LocalDateTime date) { this.date = date; }

public double getTotal() { return total; }
public void setTotal(double total) { this.total = total; }

public double getPayment() { return payment; }
public void setPayment(double payment) { this.payment = payment; }

public double getChange() { return change; }
public void setChange(double change) { this.change = change; }

}
