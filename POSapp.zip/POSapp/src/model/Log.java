/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package model;
import java.time.LocalDateTime;
/**
 *
 * @author LENOVO
 */
public class Log {
     private int id;
     private int userId;
     private String actionType; 
     private String description;
     private LocalDateTime timestamp;
    
     public Log() {}

public Log(int id, int userId, String actionType, String description, LocalDateTime timestamp) {
    this.id = id;
    this.userId = userId;
    this.actionType = actionType;
    this.description = description;
    this.timestamp = timestamp;
}

// Getters & Setters
public int getId() { return id; }
public void setId(int id) { this.id = id; }

public int getUserId() { return userId; }
public void setUserId(int userId) { this.userId = userId; }

public String getActionType() { return actionType; }
public void setActionType(String actionType) { this.actionType = actionType; }

public String getDescription() { return description; }
public void setDescription(String description) { this.description = description; }

public LocalDateTime getTimestamp() { return timestamp; }
public void setTimestamp(LocalDateTime timestamp) { this.timestamp = timestamp; }
}
